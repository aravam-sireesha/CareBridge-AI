import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { api } from '../api/client.js'
import TileMap from './TileMap.jsx'
import { describeGeoError, geolocationSupport } from '../lib/geo.js'
import { ageText, bearingLabel, formatDistance, haversineKm, navLinks } from '../lib/mapMath.js'

const SEND_EVERY_MS = 6000       // the server accepts one position every 5 s
const POLL_EVERY_MS = 10000

/** Live location and navigation for ONE delivery.
 *  - The assigned volunteer opts in per delivery, sees exactly what is shared, and can stop at any time.
 *  - The organization, donor and administrators watch only during the delivery leg, and see "waiting" or "last known" honestly.
 *  - Navigation hands the destination to a real maps app; this screen never calculates road routes or arrival times. */
export default function LiveTracking({ task, onChanged }) {
  const t = task.tracking || {}
  const [sharing, setSharing] = useState(Boolean(t.sharing))
  const [sending, setSending] = useState(false)
  const [me, setMe] = useState(null)
  const [lastSent, setLastSent] = useState(null)
  const [now, setNow] = useState(Date.now())
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const [remote, setRemote] = useState(null)
  const watch = useRef(null)
  const lastPost = useRef(0)

  useEffect(() => { setSharing(Boolean(t.sharing)) }, [t.sharing])
  useEffect(() => { const id = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(id) }, [])
  const endWatch = useCallback(() => { if (watch.current != null) { navigator.geolocation.clearWatch(watch.current); watch.current = null } setSending(false) }, [])
  useEffect(() => endWatch, [endWatch])                               // leaving the screen stops this device from sending

  const onFix = useCallback(async (pos) => {
    const fix = { latitude: pos.coords.latitude, longitude: pos.coords.longitude, accuracy_m: pos.coords.accuracy }
    setMe({ lat: fix.latitude, lon: fix.longitude, accuracy: fix.accuracy_m })
    const at = Date.now(); if (at - lastPost.current < SEND_EVERY_MS) return
    lastPost.current = at
    try { await api.sendDeliveryLocation(task.id, fix); setLastSent(Date.now()); setError('') }
    catch (e) {
      if (/Start sharing first|switched off/i.test(e.message)) { endWatch(); setSharing(false); setError('Sharing was switched off for this delivery.') }
      else if (!/accepted every few seconds/i.test(e.message)) setError(e.message)
    }
  }, [task.id, endWatch])
  const onGeoError = useCallback(async (e) => {
    setError(describeGeoError(e))
    if (e && e.code === 1) { endWatch(); setSharing(false); try { await api.deliveryTrackingStop(task.id) } catch { /* the server also clears it when the delivery ends */ } }
  }, [task.id, endWatch])
  const begin = useCallback(() => {
    const support = geolocationSupport(); if (!support.available) { setError(support.reason); return false }
    watch.current = navigator.geolocation.watchPosition(onFix, onGeoError, { enableHighAccuracy: true, maximumAge: 5000, timeout: 20000 })
    setSending(true); return true
  }, [onFix, onGeoError])

  const start = async () => {
    setBusy(true); setError('')
    try { await api.deliveryTrackingStart(task.id); setSharing(true); if (!begin()) { await api.deliveryTrackingStop(task.id); setSharing(false) } onChanged?.() }
    catch (e) { setError(e.message) } finally { setBusy(false) }
  }
  const stop = async () => {
    setBusy(true); endWatch()
    try { await api.deliveryTrackingStop(task.id); setSharing(false); setMe(null); setLastSent(null); onChanged?.() } catch (e) { setError(e.message) } finally { setBusy(false) }
  }

  // Viewers (organization, donor, administrator) poll while the page is visible.
  useEffect(() => {
    if (!t.can_watch || t.can_share) return undefined
    let live = true
    const load = async () => { try { const r = await api.getDeliveryLocation(task.id); if (live) { setRemote({ ...r, fetchedAt: Date.now() }); setError('') } } catch (e) { if (live) setError(e.message) } }
    load(); const id = setInterval(() => { if (!document.hidden) load() }, POLL_EVERY_MS)
    return () => { live = false; clearInterval(id) }
  }, [task.id, t.can_watch, t.can_share])

  const pickup = task.points?.pickup; const delivery = task.points?.delivery
  const markers = useMemo(() => {
    const m = []
    if (pickup) m.push({ id: 'pickup', kind: 'pickup', lat: pickup.latitude, lon: pickup.longitude, label: 'Pickup' })
    if (delivery) m.push({ id: 'delivery', kind: 'delivery', lat: delivery.latitude, lon: delivery.longitude, label: 'Delivery' })
    if (t.can_share && me) m.push({ id: 'me', kind: 'me', lat: me.lat, lon: me.lon, label: 'You', accuracy: me.accuracy })
    if (!t.can_share && remote?.has_position) m.push({ id: 'vol', kind: 'volunteer', lat: remote.latitude, lon: remote.longitude, label: 'Volunteer', stale: remote.stale, accuracy: remote.accuracy_m })
    return m
  }, [pickup, delivery, me, remote, t.can_share])

  const showNav = t.can_share && (pickup || delivery)
  const missingPlace = t.can_share && task.addresses_visible?.delivery && !delivery
  const sentAgo = lastSent ? Math.max(0, Math.round((now - lastSent) / 1000)) : null
  const remoteAge = remote?.has_position ? (remote.age_seconds ?? 0) + Math.round((now - remote.fetchedAt) / 1000) : null
  if (!t.can_share && !t.can_watch && !pickup && !delivery) return null

  return (
    <section className="cbt" aria-label="Live location and navigation">
      <h3>{t.can_share ? 'Navigation and live location' : 'Delivery on the map'}</h3>

      {t.can_share && !sharing && (
        <div className="cbt-consent">
          <p><strong>Share my live location for this delivery?</strong> The organization, the donor and administrators will see roughly where you are (to about 10 m) only while you are carrying the items. Only your latest position is kept, it is deleted when the delivery ends, and you can stop at any time. Nothing is shared unless you press the button.</p>
        </div>
      )}
      {t.can_share && (
        <div className="cbt-actions">
          {!sharing && <button type="button" className="cbt-btn" onClick={start} disabled={busy}>Start sharing my location</button>}
          {sharing && !sending && <button type="button" className="cbt-btn" onClick={() => begin()} disabled={busy}>Resume sending</button>}
          {sharing && <button type="button" className="cbt-btn cbt-btn--danger" onClick={stop} disabled={busy}>Stop sharing</button>}
        </div>
      )}
      {t.can_share && sharing && (
        <p className="cbt-status" role="status"><span className={`cbt-dot ${sending ? '' : 'cbt-dot--off'}`} />
          {sending ? (sentAgo == null ? 'Sharing is on. Waiting for your first position…' : `Sharing is on · last sent ${ageText(sentAgo)}${me?.accuracy ? ` · accurate to about ${Math.round(me.accuracy)} m` : ''}`) : 'Sharing is on, but this device is not sending. Resume or stop.'}</p>
      )}
      {t.can_share && sharing && <p>Keep this page open. Phones may pause location updates when the screen is off or the browser is in the background.</p>}

      {!t.can_share && t.can_watch && (
        <p className="cbt-status" role="status">
          <span className={`cbt-dot ${!remote?.has_position ? 'cbt-dot--off' : remote.stale ? 'cbt-dot--stale' : ''}`} />
          {!remote ? 'Checking…' : !remote.sharing ? 'The volunteer is not sharing a live location.' : !remote.has_position ? 'Waiting for the volunteer\u2019s first position.' : remote.stale ? `Last known position, ${ageText(remoteAge)}. The volunteer\u2019s device has not reported recently.` : `Live · updated ${ageText(remoteAge)}`}
        </p>
      )}
      {error && <div className="cbt-error" role="alert">{error}</div>}

      {markers.length > 0 && <TileMap markers={markers} height={300} ariaLabel="Delivery map" />}

      {showNav && (
        <div className="cbt-nav">
          {[['Pickup', pickup], ['Delivery', delivery]].filter(([, p]) => p).map(([name, p]) => {
            const links = navLinks(p.latitude, p.longitude, `${name}: ${p.label || 'destination'}`)
            const km = me ? haversineKm(me.lat, me.lon, p.latitude, p.longitude) : null
            return (
              <div className="cbt-dest" key={name}>
                <div><strong>{name}{p.label ? `: ${p.label}` : ''}</strong>
                  <span>{km != null ? `${formatDistance(km)} ${bearingLabel(me.lat, me.lon, p.latitude, p.longitude)} of you, in a straight line` : 'Start sharing, or open your maps app, for directions'}</span></div>
                <div className="cbt-links">
                  <a href={links.google} target="_blank" rel="noopener noreferrer">Navigate</a>
                  <a href={links.geo}>Open in maps app</a>
                  <a href={links.osm} target="_blank" rel="noopener noreferrer">OpenStreetMap</a>
                </div>
              </div>
            )
          })}
          <p>Directions open in your own maps app. CareBridge shows straight-line distance only; it does not calculate routes or arrival times.</p>
        </div>
      )}
      {missingPlace && <p>No map position is on file for the delivery place. Ask the organization to save its location in Settings, then Location. The address text above is still correct.</p>}
    </section>
  )
}
