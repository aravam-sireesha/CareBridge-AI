"""Live delivery tracking rules. Pure Python: no database, no web framework (tested in tests/test_tracking.py).

Principles:
* Opt-in per delivery. A volunteer starts sharing for ONE delivery, by pressing a button, and can stop at any time.
* Only the volunteer assigned to the delivery can report a position, and only while they hold the task.
* Only the LATEST position is kept (no breadcrumb trail), and it is deleted as soon as the delivery leaves the active stages.
* The organization, donor and administrators see it only during the delivery leg (picked up / in transit), rounded to about 11 m.
* Nothing is simulated: with no fix the answer is "no position yet", and an old fix is flagged stale rather than shown as live.
"""
from __future__ import annotations

import math
from datetime import datetime
from typing import Iterable, Optional

from . import delivery_flow as flow
from .geo import is_valid_coordinate

MIN_INTERVAL_SECONDS = 5          # a phone may call far more often than anyone needs; ignore the excess
STALE_AFTER_SECONDS = 120         # older than this is shown as "last known", not "live"
MAX_ACCURACY_M = 5000.0           # a fix this vague (cell tower or IP guess) is not useful for tracking a delivery
HOLDING_STATUSES = {flow.ACCEPTED, flow.PICKUP_SCHEDULED, flow.PICKED_UP, flow.IN_TRANSIT}   # the volunteer holds the task
VIEWER_STATUSES = {flow.PICKED_UP, flow.IN_TRANSIT}                                           # others may watch only now
VIEWER_DECIMALS = 4               # about 11 metres


class TrackingError(Exception):
    """code: forbidden (403) | invalid_state (409) | invalid_input (422) | too_soon (429)."""

    def __init__(self, code: str, message: str, retry_after: int = 0):
        super().__init__(message)
        self.code, self.message, self.retry_after = code, message, retry_after


def validate_fix(lat: object, lon: object, accuracy: object = None) -> tuple[float, float, Optional[float]]:
    if not is_valid_coordinate(lat, lon):
        raise TrackingError("invalid_input", "That is not a valid position.")
    acc = None
    if accuracy is not None:
        try:
            acc = float(accuracy)
        except (TypeError, ValueError):
            raise TrackingError("invalid_input", "The accuracy must be a number of metres.") from None
        if not math.isfinite(acc) or acc < 0:
            raise TrackingError("invalid_input", "The accuracy must be a number of metres.")
        if acc > MAX_ACCURACY_M:
            raise TrackingError("invalid_input", "The position is too imprecise to use for tracking. Move to where the device gets a better signal.")
    return float(lat), float(lon), acc


def can_start(status: str, rel: Iterable[str]) -> None:
    if "assigned_volunteer" not in set(rel):
        raise TrackingError("forbidden", "Only the volunteer assigned to this delivery can share a live location for it.")
    if status not in HOLDING_STATUSES:
        raise TrackingError("invalid_state", "Live location can only be shared while you are carrying out this delivery.")


def can_view(status: str, rel: Iterable[str]) -> bool:
    rel = set(rel)
    if "assigned_volunteer" in rel:
        return status in HOLDING_STATUSES
    if rel & {"org_owner", "donor_owner", "admin"}:
        return status in VIEWER_STATUSES
    return False


def seconds_to_wait(last_recorded_at: Optional[datetime], now: datetime) -> int:
    if last_recorded_at is None:
        return 0
    return max(0, math.ceil(MIN_INTERVAL_SECONDS - (now - last_recorded_at).total_seconds()))


def age_seconds(recorded_at: Optional[datetime], now: datetime) -> Optional[int]:
    return None if recorded_at is None else max(0, int((now - recorded_at).total_seconds()))


def present(fix: Optional[dict], now: datetime, rel: Iterable[str]) -> dict:
    """What a viewer receives. `fix` = {latitude, longitude, accuracy_m, recorded_at} or None. Others get rounded coordinates."""
    if not fix or fix.get("latitude") is None or fix.get("longitude") is None:
        return {"has_position": False}
    own = "assigned_volunteer" in set(rel)
    lat, lon = (fix["latitude"], fix["longitude"]) if own else (round(fix["latitude"], VIEWER_DECIMALS), round(fix["longitude"], VIEWER_DECIMALS))
    age = age_seconds(fix.get("recorded_at"), now)
    return {"has_position": True, "latitude": lat, "longitude": lon, "accuracy_m": fix.get("accuracy_m"),
            "recorded_at": fix["recorded_at"].isoformat() if fix.get("recorded_at") else None, "age_seconds": age,
            "stale": age is None or age > STALE_AFTER_SECONDS}


def keeps_position(new_status: str) -> bool:
    """The stored position is deleted as soon as a delivery moves to a status where tracking is not allowed."""
    return new_status in HOLDING_STATUSES
