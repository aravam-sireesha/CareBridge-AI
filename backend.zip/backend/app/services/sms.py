"""SMS delivery boundary. Nothing is sent unless a real provider is configured, and "sent" is reported only after the provider accepted it.

Configure with environment variables (never in code):
    SMS_PROVIDER=twilio
    TWILIO_ACCOUNT_SID=...   TWILIO_AUTH_TOKEN=...   TWILIO_FROM=+15551234567
Without them `provider_from_env()` returns None and callers must say "SMS is not configured", never pretend. Phone numbers, codes and
credentials are never logged and never appear in a provider object's repr.

This is the INTEGRATION BOUNDARY: it is not yet wired into registration (the sign-up form collects no phone number) or recovery.
Wiring it needs a phone-number field, its own verification rules and, in many countries, sender registration (e.g. DLT in India).
"""
from __future__ import annotations

import base64
import logging
import os
import re
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Callable, Mapping, Optional

logger = logging.getLogger("carebridge.sms")
Transport = Callable[[str, bytes, Mapping[str, str]], int]       # (url, form body, headers) -> HTTP status; raises on network failure


def normalize_phone(raw: object, default_country_code: str = "") -> Optional[str]:
    """Any reasonable human input -> E.164 ("+919876543210"), or None. A bare number needs `default_country_code` ("91")."""
    text = str(raw or "").strip()
    if not text or len(text) > 30 or re.search(r"[^\d\s()+\-.]", text):
        return None
    digits = re.sub(r"\D", "", text)
    if text.startswith("+") or text.startswith("00"):
        digits = digits[2:] if text.startswith("00") else digits
    elif default_country_code:
        digits = default_country_code.lstrip("+") + digits.lstrip("0")
    else:
        return None
    return "+" + digits if 8 <= len(digits) <= 15 and digits[0] != "0" else None


def mask(phone: str) -> str:
    return phone[:3] + "*" * max(0, len(phone) - 5) + phone[-2:] if phone and len(phone) > 6 else "***"


def _urllib_transport(url: str, body: bytes, headers: Mapping[str, str]) -> int:
    req = urllib.request.Request(url, data=body, headers=dict(headers), method="POST")
    with urllib.request.urlopen(req, timeout=10) as resp:               # raises HTTPError (a URLError) for 4xx/5xx
        return resp.status


@dataclass(frozen=True)
class SmsResult:
    ok: bool
    mode: str


class TwilioProvider:
    mode = "twilio"

    def __init__(self, sid: str, token: str, sender: str, transport: Optional[Transport] = None):
        self._sid, self._token, self._sender, self._transport = sid, token, sender, transport or _urllib_transport

    def __repr__(self) -> str:                                          # never expose the credentials
        return "TwilioProvider(configured)"

    def send(self, to: str, text: str) -> SmsResult:
        if normalize_phone(to) != to:
            return SmsResult(False, self.mode)
        url = f"https://api.twilio.com/2010-04-01/Accounts/{urllib.parse.quote(self._sid)}/Messages.json"
        auth = base64.b64encode(f"{self._sid}:{self._token}".encode()).decode()
        body = urllib.parse.urlencode({"To": to, "From": self._sender, "Body": text}).encode()
        try:
            status = self._transport(url, body, {"Authorization": f"Basic {auth}", "Content-Type": "application/x-www-form-urlencoded"})
        except Exception as exc:                                         # network failure or an HTTP error status
            logger.warning("SMS delivery failed (%s)", type(exc).__name__)    # no number, no text, no credentials
            return SmsResult(False, self.mode)
        return SmsResult(200 <= status < 300, self.mode)


def provider_from_env(env: Mapping[str, str] | None = None, transport: Optional[Transport] = None):
    """The configured provider, or None when SMS is not (fully) configured."""
    env = os.environ if env is None else env
    if (env.get("SMS_PROVIDER") or "").strip().lower() != "twilio":
        return None
    sid, token, sender = (env.get(k, "").strip() for k in ("TWILIO_ACCOUNT_SID", "TWILIO_AUTH_TOKEN", "TWILIO_FROM"))
    if not (sid and token and normalize_phone(sender)):
        return None                                                      # half-configured is not configured
    return TwilioProvider(sid, token, normalize_phone(sender), transport)


def send_code(to: str, code: str, ttl_minutes: int, env: Mapping[str, str] | None = None, transport: Optional[Transport] = None) -> SmsResult:
    provider = provider_from_env(env, transport)
    if provider is None:
        return SmsResult(False, "none")
    return provider.send(to, f"Your CareBridge code is {code}. It expires in {ttl_minutes} minutes. Do not share it.")
