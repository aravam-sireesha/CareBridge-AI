"""SMS boundary: pure Python, no network. Run with:  python -m pytest tests/test_sms.py -q"""
import logging
import urllib.parse

from app.services import sms

ENV = {"SMS_PROVIDER": "twilio", "TWILIO_ACCOUNT_SID": "ACsecretsid", "TWILIO_AUTH_TOKEN": "supersecrettoken", "TWILIO_FROM": "+15551234567"}


def test_phone_numbers_are_normalised_or_refused():
    assert sms.normalize_phone("+91 98765 43210") == "+919876543210"
    assert sms.normalize_phone("0091 98765 43210") == "+919876543210"
    assert sms.normalize_phone("098765 43210", "91") == "+919876543210" and sms.normalize_phone("9876543210", "+91") == "+919876543210"
    for bad in ("", None, "9876543210", "+0123456", "+12", "call me", "+91 98765 4321O", "+" + "9" * 20, "+91 98765; DROP TABLE"):
        assert sms.normalize_phone(bad) is None, bad


def test_masking_hides_most_of_the_number():
    assert sms.mask("+919876543210") == "+91********10" and sms.mask("123") == "***"


def test_nothing_is_configured_means_no_provider_and_no_pretending():
    assert sms.provider_from_env({}) is None
    assert sms.send_code("+919876543210", "123456", 10, {}) == sms.SmsResult(False, "none")
    for missing in ("TWILIO_ACCOUNT_SID", "TWILIO_AUTH_TOKEN", "TWILIO_FROM"):
        partial = {k: v for k, v in ENV.items() if k != missing}
        assert sms.provider_from_env(partial) is None, missing
    assert sms.provider_from_env({**ENV, "TWILIO_FROM": "not a number"}) is None
    assert sms.provider_from_env({**ENV, "SMS_PROVIDER": "carrier-pigeon"}) is None


def test_a_successful_send_is_reported_only_after_the_provider_accepts():
    seen = {}

    def fake(url, body, headers):
        seen.update(url=url, body=urllib.parse.parse_qs(body.decode()), headers=headers); return 201
    res = sms.send_code("+919876543210", "123456", 10, ENV, fake)
    assert res == sms.SmsResult(True, "twilio")
    assert seen["url"] == "https://api.twilio.com/2010-04-01/Accounts/ACsecretsid/Messages.json"
    assert seen["body"]["To"] == ["+919876543210"] and seen["body"]["From"] == ["+15551234567"] and "123456" in seen["body"]["Body"][0] and "Do not share" in seen["body"]["Body"][0]
    assert seen["headers"]["Authorization"].startswith("Basic ")


def test_provider_errors_and_network_failures_are_failures_and_never_leak_anything():
    records = []

    class Catch(logging.Handler):
        def emit(self, r): records.append(r.getMessage())
    h = Catch(); sms.logger.addHandler(h); sms.logger.setLevel(logging.DEBUG)
    try:
        assert sms.send_code("+919876543210", "654321", 10, ENV, lambda *a: 400) == sms.SmsResult(False, "twilio")
        assert sms.send_code("+919876543210", "654321", 10, ENV, lambda *a: (_ for _ in ()).throw(OSError("network down"))) == sms.SmsResult(False, "twilio")
    finally:
        sms.logger.removeHandler(h)
    joined = " ".join(records)
    assert records and all(x not in joined for x in ("654321", "+919876543210", "ACsecretsid", "supersecrettoken"))


def test_an_invalid_destination_is_never_sent_to_the_provider():
    called = []
    assert sms.send_code("98765", "123456", 10, ENV, lambda *a: called.append(1) or 201).ok is False and called == []


def test_the_provider_object_never_shows_its_credentials():
    p = sms.provider_from_env(ENV)
    assert "supersecrettoken" not in repr(p) and "ACsecretsid" not in repr(p) and "supersecrettoken" not in str(p)
